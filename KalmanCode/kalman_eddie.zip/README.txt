Edward Jeffs 
Robot Motion Planning and Control Final Project

kalmanFin.py:
    The generic program which runs the simulation infinitely or until the window is closed.

kalmanFinRecord.py:
    records a gif of the simulation, and plots the error and uncertainty of the kalman filter. 

    kalman_analysis.png:
        plots of the error and uncertainty of the kalman filter

    pygame_simulation.gif
        the recording of the simulation